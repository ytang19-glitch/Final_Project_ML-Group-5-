"""
Input/output helpers.
"""

from pathlib import Path
import pandas as pd


def load_data(path: str) -> pd.DataFrame:
    return pd.read_csv(path)


def ensure_dir(path: str) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
