"""
Feature engineering for AQI forecasting.

All transformations should be leakage-safe: only past information is used
to predict future AQI.
"""

import pandas as pd
import numpy as np


def add_time_features(df: pd.DataFrame, date_col: str = "date") -> pd.DataFrame:
    df = df.copy()
    df[date_col] = pd.to_datetime(df[date_col])
    df["dayofweek"] = df[date_col].dt.dayofweek
    df["dayofyear"] = df[date_col].dt.dayofyear
    df["month"] = df[date_col].dt.month

    for col in ["dayofweek", "dayofyear", "month"]:
        df[f"{col}_sin"] = np.sin(2 * np.pi * df[col] / df[col].max())
        df[f"{col}_cos"] = np.cos(2 * np.pi * df[col] / df[col].max())

    return df


def add_lag_features(df: pd.DataFrame, group_col: str, target_col: str, lags=None) -> pd.DataFrame:
    if lags is None:
        lags = [1, 2, 3, 12, 24]
    df = df.copy()
    df = df.sort_values([group_col, "date"])
    for lag in lags:
        df[f"{target_col}_lag{lag}"] = df.groupby(group_col)[target_col].shift(lag)
    return df


def add_rolling_features(df: pd.DataFrame, group_col: str, target_col: str, windows=None) -> pd.DataFrame:
    if windows is None:
        windows = [3, 5]
    df = df.copy()
    df = df.sort_values([group_col, "date"])
    for w in windows:
        df[f"{target_col}_roll{w}"] = (
            df.groupby(group_col)[target_col].shift(1).rolling(w).mean()
        )
    return df
