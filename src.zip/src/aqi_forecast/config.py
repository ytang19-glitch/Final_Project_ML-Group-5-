"""
Configuration helpers for the AQI forecasting project.
"""

from dataclasses import dataclass


@dataclass
class TrainConfig:
    data_path: str
    horizon_days: int = 3
    model_type: str = "linear"
    model_output_path: str = "models/best_model.joblib"
