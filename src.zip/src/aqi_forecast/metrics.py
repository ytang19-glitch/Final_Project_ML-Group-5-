"""
Metrics helpers for AQI forecasting.
"""

from typing import Dict

import numpy as np
from sklearn import metrics


def regression_metrics(y_true, y_pred) -> Dict[str, float]:
    rmse = float(np.sqrt(metrics.mean_squared_error(y_true, y_pred)))
    mae = float(metrics.mean_absolute_error(y_true, y_pred))
    mape = float(metrics.mean_absolute_percentage_error(y_true, y_pred) * 100)
    r2 = float(metrics.r2_score(y_true, y_pred))
    return {"rmse": rmse, "mae": mae, "mape": mape, "r2": r2}
