"""
Plotting helpers for AQI forecasting.
"""

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


def plot_predictions(
    df: pd.DataFrame,
    date_col: str,
    y_true_col: str,
    y_pred_col: str,
    city: str,
    out_path: str,
) -> None:
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    sub = df[df["City"] == city].sort_values(date_col)
    plt.figure()
    plt.plot(sub[date_col], sub[y_true_col], label="True")
    plt.plot(sub[date_col], sub[y_pred_col], label="Predicted")
    plt.xlabel("Date")
    plt.ylabel("AQI level")
    plt.title(f"AQI prediction — {city}")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_path)
    plt.close()
