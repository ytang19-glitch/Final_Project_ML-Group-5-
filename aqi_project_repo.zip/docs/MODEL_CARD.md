# Model Card — AQI Forecasting (India, Multi-City)

This model card documents the **final selected model** used in our AQI forecasting pipeline.
The model performs **3-day ahead AQI level prediction (1–5)** using multi-city pollution and weather data.

---

## 1. Model Details

| Field           | Description                                      |
|----------------|--------------------------------------------------|
| Model Name     | AQI 3-Day Ahead Forecast — Linear Regression     |
| Version        | v1.0                                             |
| Model Type     | Regression (continuous output, 1–5 AQI levels)   |
| Developers     | Group 5 (replace with actual names)              |
| Release Date   | 2025-12-08 (edit as needed)                      |
| Framework      | Python, scikit-learn                             |

---

## 2. Intended Use

### Primary use

- City-level **3-day ahead AQI forecasting** (levels 1–5).
- Provide early-warning style information for pollution risk.
- Support dashboards and exploratory analysis for environmental researchers.

### Intended users

- Environmental and municipal agencies.
- Researchers and students studying air quality.
- Analysts building AQI dashboards or reports.

### Out-of-scope uses

- Individual-level health or medical decision making.
- Legal enforcement or compliance auditing.
- Real-time industrial control or mission-critical systems.

---

## 3. Data Description

- Multi-city Indian AQI dataset.
- Example columns:
  - `City`, `date` / `datetime`.
  - pollutants: `PM2.5`, `PM10`, `NO2`, `SO2`, `CO`, `O3`.
  - optional weather: temperature, humidity, wind speed, pressure, rainfall.
  - `aqi` (1–5) used as target.
- Data is split chronologically into train / validation / test to avoid leakage.

---

## 4. Feature Engineering

Implemented in `src/aqi_forecast/features.py`:

- Per-city target shift: **AQI(t + 3 days)**.
- Lag features on key pollutants and/or AQI:
  - 1, 2, 3, 12, 24 time steps.
- Rolling statistics:
  - e.g., `shift(1).rolling(3)` and `shift(1).rolling(5)` means, using only past values.
- Calendar / cyclic features:
  - day-of-week, month, day-of-year encoded as sin/cos pairs.
- City is one-hot encoded.

All features are computed in a **leakage-safe** way: no row is allowed to use information from the future.

---

## 5. Model Architecture

The final model is a **scikit-learn Pipeline**:

1. Preprocessing:
   - Numeric imputation (if needed).
   - StandardScaler on numeric features.
   - OneHotEncoder on `City` (handle unknown='ignore').
2. Estimator:
   - `LinearRegression`.

Other models (Random Forest, XGBoost, GRU, LSTM, Hybrid LSTM–GRU) were explored as baselines but are not part of the final, documented deployment model.

---

## 6. Training Procedure

- Loss: mean squared error (via LinearRegression).
- Optimization: closed-form solution computed by scikit-learn.
- Evaluation:
  - Chronological split (no shuffle).
  - ~70% train, ~15% validation, ~15% test.
- Implementation:
  - see `scripts/train.py` and `scripts/evaluate.py`.

---

## 7. Evaluation Metrics

Metrics used:

- RMSE  
- MAE  
- MAPE  
- R²  

Final model performance (Linear Regression) on the held-out **test set**:

| Split | RMSE  | MAE   | MAPE   | R²    |
|------:|:-----:|:-----:|:------:|:-----:|
| Test  | 0.968 | 0.693 | 26.968 | 0.336 |

A full comparison against other candidate models (XGBoost, Random Forest, GRU, LSTM, Hybrid LSTM–GRU) is provided in `docs/EVALUATION.md`.

---

## 8. Ethical Considerations

### Fairness and bias

- Monitoring stations may be unevenly distributed across cities or regions, introducing geographic bias.
- Historical data may reflect specific episodes (e.g., lockdowns, festivals) more than others.
- AQI forecasts should be presented with uncertainty and not over-interpreted as exact truth.

### Privacy

- The dataset contains **no individual-level data**: all records are aggregated at city–time level.
- No personally identifiable information (PII) is used.

### Security

- The model itself does not pose security risks.
- When deployed as an API or service, standard security practices (access control, rate limiting) should be applied.

---

## 9. Limitations

- Extreme pollution events (festivals, burning events, dust storms) are harder to predict and often underestimated.
- Performance can be weaker for cities with sparse or inconsistent records.
- Linear Regression cannot capture complex non-linear relationships; it is intended as a strong baseline rather than a final production model in all contexts.

---

## 10. Recommendations for Use

- Retrain the model periodically as new data becomes available.
- Always communicate forecast uncertainty and avoid overly precise claims.
- Consider combining this baseline with more advanced models (XGBoost, LSTM) if a production system is needed.
- Use the model as decision support, not as an automatic decision maker.

---

## 11. Additional Information

### References

- Mitchell et al., 2019. *Model Cards for Model Reporting.*
- Google Model Cards: https://modelcards.withgoogle.com/about
- Any AQI or air-quality references used in the project report.

### License

- Specify your project license here (e.g., MIT, Apache 2.0, or “for educational use only”).

### Contact

- For questions or issues, please contact the course team or the project authors (insert emails or GitHub profiles).
