"""
Train script for AQI forecasting project.

Example:
    python scripts/train.py --data data/air_pollution_data.csv --model linear --horizon-days 3
"""

import argparse
from pathlib import Path

import joblib
import pandas as pd

from aqi_forecast.config import TrainConfig
from aqi_forecast.features import add_time_features, add_lag_features, add_rolling_features
from aqi_forecast.io import ensure_dir, load_data
from aqi_forecast.metrics import regression_metrics
from aqi_forecast.pipeline import build_pipeline


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--data", required=True, help="Path to CSV with AQI data.")
    p.add_argument("--model", default="linear", choices=["linear", "rf"])
    p.add_argument("--horizon-days", type=int, default=3)
    p.add_argument("--model-output", default="models/best_model.joblib")
    return p.parse_args()


def main():
    args = parse_args()
    cfg = TrainConfig(
        data_path=args.data,
        horizon_days=args.horizon_days,
        model_type=args.model,
        model_output_path=args.model_output,
    )

    df = load_data(cfg.data_path)

    # Feature engineering (simplified; adjust columns to your real dataset)
    df = add_time_features(df, date_col="date")
    df = add_lag_features(df, group_col="City", target_col="aqi")
    df = add_rolling_features(df, group_col="City", target_col="aqi")

    # Drop rows with missing values created by lags/rolling
    df = df.dropna().reset_index(drop=True)

    feature_cols = [
        c
        for c in df.columns
        if c
        not in {
            "aqi",
            "date",
        }
    ]
    numeric_features = [c for c in feature_cols if df[c].dtype != "object"]
    categorical_features = [c for c in feature_cols if df[c].dtype == "object"]

    # Simple time-based split
    df = df.sort_values("date")
    n = len(df)
    train_end = int(n * 0.7)
    valid_end = int(n * 0.85)

    train = df.iloc[:train_end]
    valid = df.iloc[train_end:valid_end]
    test = df.iloc[valid_end:]

    pipeline = build_pipeline(
        numeric_features=numeric_features,
        categorical_features=categorical_features,
        model_type=cfg.model_type,
    )

    X_train = train[feature_cols]
    y_train = train["aqi"]
    X_valid = valid[feature_cols]
    y_valid = valid["aqi"]

    pipeline.fit(X_train, y_train)
    y_valid_pred = pipeline.predict(X_valid)
    metrics = regression_metrics(y_valid, y_valid_pred)

    print("Validation metrics:", metrics)

    ensure_dir(cfg.model_output_path)
    joblib.dump(pipeline, cfg.model_output_path)
    print(f"Saved model to {cfg.model_output_path}")


if __name__ == "__main__":
    main()
