"""
Evaluation script for AQI forecasting project.

Example:
    python scripts/evaluate.py --data data/air_pollution_data.csv --model-path models/best_model.joblib --plot-city Ahmedabad
"""

import argparse

import joblib
import pandas as pd

from aqi_forecast.features import add_time_features, add_lag_features, add_rolling_features
from aqi_forecast.metrics import regression_metrics
from aqi_forecast.plots import plot_predictions


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--data", required=True)
    p.add_argument("--model-path", required=True)
    p.add_argument("--plot-city", default=None, help="City name for prediction plot.")
    p.add_argument("--out-plot", default="assets/best_model_prediction_plot.png")
    return p.parse_args()


def main():
    args = parse_args()
    df = pd.read_csv(args.data)

    df = add_time_features(df, date_col="date")
    df = add_lag_features(df, group_col="City", target_col="aqi")
    df = add_rolling_features(df, group_col="City", target_col="aqi")
    df = df.dropna().reset_index(drop=True)

    feature_cols = [
        c
        for c in df.columns
        if c
        not in {
            "aqi",
            "date",
        }
    ]

    df = df.sort_values("date")
    n = len(df)
    valid_end = int(n * 0.85)
    test = df.iloc[valid_end:]

    X_test = test[feature_cols]
    y_test = test["aqi"]

    model = joblib.load(args.model_path)
    y_pred = model.predict(X_test)

    metrics = regression_metrics(y_test, y_pred)
    print("Test metrics:", metrics)

    test = test.copy()
    test["aqi_pred"] = y_pred

    if args.plot_city is not None:
        plot_predictions(
            test,
            date_col="date",
            y_true_col="aqi",
            y_pred_col="aqi_pred",
            city=args.plot_city,
            out_path=args.out_plot,
        )


if __name__ == "__main__":
    main()
