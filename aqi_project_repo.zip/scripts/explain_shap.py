"""
SHAP explainability script for AQI forecasting project.

Example:
    python scripts/explain_shap.py --data data/air_pollution_data.csv --model-path models/best_model.joblib
"""

import argparse
from pathlib import Path

import joblib
import pandas as pd
import shap

from aqi_forecast.features import add_time_features, add_lag_features, add_rolling_features


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--data", required=True)
    p.add_argument("--model-path", required=True)
    p.add_argument("--out-bar", default="assets/shap_bar_best_model.png")
    p.add_argument("--out-summary", default="assets/shap_summary_best_model.png")
    return p.parse_args()


def main():
    args = parse_args()
    df = pd.read_csv(args.data)

    df = add_time_features(df, date_col="date")
    df = add_lag_features(df, group_col="City", target_col="aqi")
    df = add_rolling_features(df, group_col="City", target_col="aqi")
    df = df.dropna().reset_index(drop=True)

    feature_cols = [
        c
        for c in df.columns
        if c
        not in {
            "aqi",
            "date",
        }
    ]

    df = df.sort_values("date")
    n = len(df)
    valid_end = int(n * 0.85)
    test = df.iloc[valid_end:]

    X_test = test[feature_cols]

    model = joblib.load(args.model_path)

    # SHAP with a sample of the data for speed
    explainer = shap.Explainer(model.predict, X_test)
    shap_values = explainer(X_test)

    Path(args.out_bar).parent.mkdir(parents=True, exist_ok=True)
    shap.plots.bar(shap_values, show=False)
    import matplotlib.pyplot as plt

    plt.tight_layout()
    plt.savefig(args.out_bar)
    plt.close()

    shap.plots.beeswarm(shap_values, show=False)
    plt.tight_layout()
    plt.savefig(args.out_summary)
    plt.close()


if __name__ == "__main__":
    main()
