# Final_Project_ML-Group-5 — AQI Forecasting (India, Multi-City)

This repository predicts short-term **Air Quality Index (AQI, levels 1–5)** for multiple Indian cities using publicly available air-pollution and meteorological data.
Our main configuration performs **3-day ahead forecasting** by shifting the target to **AQI(t + 3 days)** while strictly ensuring **no future information leakage**.

---

## What this project does
- Forecast city-level AQI (1–5) for the next **24–72 hours**.
- Provide early-warning insight for pollution-risk windows.
- Support classical ML and explainability workflows.
- Use **strict time-split evaluation** to avoid leakage.
- Generate diagnostics including SHAP charts and prediction curves.
- Offer a clean, reusable Python package under `src/aqi_forecast/`.

---

## Data format

The input CSV should contain:

- `City` (categorical)
- `date` / `datetime` column
- pollutant data: `PM2.5`, `PM10`, `NO2`, `SO2`, `CO`, `O3`
- meteorological data (if available): temperature, humidity, wind speed, pressure, rainfall
- `aqi` (target label, typically discrete **1–5**)

**Notes**
- Predicting AQI using pollutants at the **same timestamp** is valid.
- Do **not** construct AQI-from-PM formulas (creates leakage).
- All lag/rolling features must come from **past-only** values.

---

## Pipeline summary

### Split
- Time-ordered (no shuffling).
- Final ~20% as test set.

### Feature engineering (leakage-safe)
- Lag features: 1, 2, 3, 12, 24.
- Rolling means: `shift(1).rolling(3/5)`.
- Date-based cyclical features (sin/cos).
- City one-hot encoding.

### Models
- Linear Regression (final selected model).
- Random Forest, XGBoost, GRU, LSTM, Hybrid LSTM–GRU (research/benchmark only).
- SHAP explainability.

### Evaluation metrics
- RMSE, MAE, MAPE, R².
- Rounded accuracy (AQI level classification 1–5).

---

## Repository layout

```text
.
├── README.md
├── docs/
│   ├── MODEL_CARD.md
│   └── EVALUATION.md
├── src/
│   └── aqi_forecast/
│       ├── config.py
│       ├── features.py
│       ├── io.py
│       ├── metrics.py
│       ├── models.py
│       ├── pipeline.py
│       └── plots.py
├── scripts/
│   ├── train.py
│   ├── evaluate.py
│   └── explain_shap.py
├── assets/              # generated plots
├── research/            # notebooks (not graded for code quality)
├── models/              # saved trained model(s)
└── requirements.txt
```

---

## How to run

### 1) Install environment

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -U pip
pip install -r requirements.txt
pip install -e .
```

---

### 2) Train the model

```bash
python scripts/train.py \
    --data data/air_pollution_data.csv \
    --model linear \
    --horizon-days 3
```

**Outputs**

- `models/best_model.joblib`
- validation/test metrics printed in terminal

---

### 3) Evaluate (metrics + prediction plots)

```bash
python scripts/evaluate.py \
    --data data/air_pollution_data.csv \
    --model-path models/best_model.joblib \
    --plot-city Ahmedabad
```

**Outputs saved to `assets/`:**

- `best_model_prediction_plot.png`
- `monthly_mean_aqi.png`

---

### 4) SHAP explainability (feature safety)

```bash
python scripts/explain_shap.py \
    --data data/air_pollution_data.csv \
    --model-path models/best_model.joblib
```

**Outputs saved to `assets/`:**

- `shap_bar_best_model.png`
- `shap_summary_best_model.png`

---

## Expected outputs

- Model metrics (validation & test).
- True vs Predicted AQI plot.
- Monthly AQI seasonal curve.
- SHAP bar and summary charts.
- Final model card in `docs/MODEL_CARD.md`.
- Evaluation summary in `docs/EVALUATION.md`.

---

## Notes on interpretation

- AQI levels are **discrete (1–5)**, so R² may appear modest even with low MAE.
- SHAP should be checked for leakage:
  - Any feature relying on future values is a red flag.
- Time-split evaluation is **mandatory**; shuffling inflates performance.

---

## Contact

For questions regarding training scripts or modeling choices:  
**Your Name • Your Email / GitHub**
