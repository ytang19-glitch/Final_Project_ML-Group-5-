"""
Model factory for AQI forecasting.
"""

from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from typing import Literal


def make_model(model_type: Literal["linear", "rf"] = "linear"):
    if model_type == "linear":
        return LinearRegression()
    if model_type == "rf":
        return RandomForestRegressor(
            n_estimators=200,
            random_state=42,
            n_jobs=-1,
        )
    raise ValueError(f"Unsupported model_type: {model_type}")
