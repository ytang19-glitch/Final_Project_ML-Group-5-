"""
aqi_forecast: reusable code for AQI forecasting project.

This package is used by the training / evaluation scripts in `scripts/`.
"""
