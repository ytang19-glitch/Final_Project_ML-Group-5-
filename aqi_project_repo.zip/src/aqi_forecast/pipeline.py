"""
End-to-end sklearn pipeline construction for AQI forecasting.
"""

from typing import List

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from .models import make_model


def build_pipeline(
    numeric_features: List[str],
    categorical_features: List[str],
    model_type: str = "linear",
) -> Pipeline:
    numeric_transformer = Pipeline(
        steps=[("scaler", StandardScaler())]
    )
    categorical_transformer = Pipeline(
        steps=[("onehot", OneHotEncoder(handle_unknown="ignore"))]
    )

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", numeric_transformer, numeric_features),
            ("cat", categorical_transformer, categorical_features),
        ]
    )

    model = make_model(model_type)
    clf = Pipeline(
        steps=[("preprocessor", preprocessor), ("model", model)]
    )
    return clf
