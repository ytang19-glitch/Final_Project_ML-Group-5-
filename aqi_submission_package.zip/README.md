# AQI Forecasting (India, Multi‑City) — 3‑Day Ahead

This project forecasts **Air Quality Index (AQI) levels (1–5)** for multiple Indian cities **3 days ahead** using historical pollution measurements and time‑based features. The pipeline is designed to **avoid feature leakage** (no future values and no “same‑day AQI” shortcut).

## What’s in this repo

- **`research/`** — notebooks for exploration / EDA (not graded for code quality).
- **`src/`** — reusable Python package (feature engineering, splits, training, evaluation).
- **`scripts/`** — thin CLI wrappers for training/evaluation.
- **`docs/`** — model card + architecture/deployment vision.
- **`assets/`** — saved figures used in the report/model card.

> Current implementation is in notebooks. The recommended `src/` + `scripts/` layout below matches the code logic in the notebooks.

### Key notebooks
- `Technical_Description_of_the_Proposed_Approach_api.ipynb`  
  End‑to‑end pipeline: target creation (+3 days), feature engineering (lags/rolling), train/eval (LR, RF, XGB, LSTM/GRU/Hybrid), best‑model plots + SHAP.
- `Final_Project_ML.ipynb`  
  Narrative/EDA version of the project (intro + data exploration).

## Data

Expected input CSV (example: `air_pollution_data.csv`) contains at least:

- `City` (categorical)
- `Date` (parseable datetime)
- pollutant columns (when available): `PM2.5`, `PM10`, `CO`, `NO`, `NO2`, `O3`, `SO2`, `NH3`

**Preprocessing (as in code):**
- drop duplicates
- parse `Date`, sort by `City, Date`
- convert pollutant/AQI columns to numeric and clip to non‑negative

## Forecast target (no leakage)

We predict: **AQI(t + 3 days)**.

Because some cities have missing dates (not every day recorded), the notebook checks how often a simple `shift(-3)` differs from an exact “+3 calendar days” alignment. Observed mismatch rate is **~0.35%** (0.00349), so `shift(-3)` alignment is acceptable for this dataset.

## Features (reusable)

1) **Cyclical time features**
- day‑of‑week sin/cos
- day‑of‑year sin/cos
- normalized city‑local time index `t` sin/cos

2) **Lag + rolling statistics (history only)**
- `AQI_lag{1,2,3,7,14}`, `AQI_roll3`, `AQI_roll5`
- pollutant lags/rolls for available pollutant columns

## Train/test split

A **time‑based per‑city split**:
- for each city, last **20%** of rows → test
- remaining **80%** → train  
This preserves temporal ordering and prevents future leakage across time.

Categorical feature handling:
- one‑hot encode categorical columns (e.g., `City`) with `drop_first=True`.

Scaling:
- `StandardScaler` fit on train, applied to test.

## Models trained

- Classical ML (regression):
  - **Linear Regression**
  - Random Forest Regressor
  - XGBoost Regressor
- Deep Learning (sequence models, `seq_len=24`):
  - LSTM
  - GRU
  - Hybrid LSTM‑GRU

Predictions are clipped to the valid AQI level range: **1–5**.

## Evaluation

Metrics (test split):
- RMSE, MAE, MAPE, R²

Latest comparison table from the pipeline:

| Model | RMSE | MAE | MAPE | R² |
|---|---:|---:|---:|---:|
| Linear Regression | 0.968459 | 0.692942 | 26.967578 | 0.336485 |
| XGBoost | 1.013902 | 0.744450 | 29.516507 | 0.272758 |
| Random Forest | 1.023085 | 0.756943 | 30.077003 | 0.259524 |
| Hybrid LSTM‑GRU | 1.103536 | 0.790775 | 30.421396 | 0.138489 |
| LSTM | 1.249584 | 0.875271 | 35.091087 | -0.104635 |
| GRU | 1.296789 | 0.930587 | 38.212154 | -0.189668 |

**Saved figures (from the notebook):**
- `assets/best_model_prediction_plot.png` — best model prediction vs actual (first 300 points)
- `assets/monthly_mean_aqi.png` — seasonal monthly mean AQI
- `assets/event_vs_nonevent_aqi.png` — event vs non‑event AQI visualization used in seasonal analysis
- `assets/shap_summary_best_model.png` — SHAP summary plot (best classical model)
- `assets/shap_bar_best_model.png` — SHAP feature importance (bar)

## How to run (notebook workflow)

1) Open `Technical_Description_of_the_Proposed_Approach_api.ipynb`.
2) Set `DATA_PATH` to your CSV location (local path or mounted Drive).
3) Run all cells from top to bottom.

Outputs:
- `model_comparison_results_full.csv`
- best‑model plot + seasonality plots + SHAP plots (see `assets/`)

## Recommended “clean” training/evaluation entrypoints (for final submission)

Create a small Python library so notebooks can import reusable code:

```
src/aqi_forecast/
  __init__.py
  data.py          # load & clean
  features.py      # cyclical + lag/rolling
  split.py         # per-city time split
  train.py         # model training
  eval.py          # metrics + plots
  explain.py       # SHAP (classical models)
scripts/
  train.py
  evaluate.py
```

Example CLI (matching the notebook logic):

```bash
python scripts/train.py --data data/air_pollution_data.csv --horizon 3 --test-frac 0.2 --out runs/run1
python scripts/evaluate.py --run runs/run1
```

## Deployment vision (high level)

See `docs/architecture.md` for a diagram and next steps for turning this into a scheduled forecasting service (data ingestion → feature pipeline → model → predictions to end users).

---

Maintained by: *(fill in names)*  
Last updated: 2025-12-08
