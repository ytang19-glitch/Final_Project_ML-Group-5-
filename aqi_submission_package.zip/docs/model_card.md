# Model Card — AQI 3‑Day Ahead Forecast (Best Model)

## Model Details
- **Model Name:** AQI 3‑Day Ahead Forecast — Linear Regression (best by RMSE)
- **Model Version:** v1.0
- **Model Type:** Regression (continuous prediction clipped to AQI levels 1–5)
- **Developers:** *(fill in team / names)*
- **Release Date:** 2025-12-08

## Intended Use
- **Primary Use:** Short‑term AQI level forecasting (early‑warning style) up to **3 days ahead** for supported Indian cities.
- **Intended Users:** Students / researchers / analysts exploring AQI forecasting pipelines.
- **Out‑of‑Scope Use Cases:**  
  - Medical or clinical decision making  
  - Regulatory enforcement  
  - High‑stakes operational decisions without additional validation

## Model & Data Description

### Data Used
- **Format:** tabular time series by city with a `Date` column.
- **Key columns used:** `City`, `Date`, and pollutant measurements when available (e.g., `PM2.5`, `PM10`, `CO`, `NO`, `NO2`, `O3`, `SO2`, `NH3`).
- **Preprocessing:** duplicates removed; `Date` parsed; per‑city sorting; numeric coercion and non‑negative clipping.
- **Target:** `AQI_tplus3` constructed by aligning **AQI(t + 3 days)**.

> Missing dates exist for some cities. The pipeline measured the mismatch between `shift(-3)` and an exact “+3 calendar days” match; mismatch rate was **~0.35%**, so the shift approach is acceptable for this dataset.

### Features
1) **Cyclical time features**  
`dow_sin`, `dow_cos`, `doy_sin`, `doy_cos`, `t_sin`, `t_cos`

2) **Lag/rolling (history only)**  
`AQI_lag{1,2,3,7,14}`, `AQI_roll3`, `AQI_roll5`, and corresponding pollutant lags/rolls

3) **Categoricals**  
`City` one‑hot encoded (drop_first=True)

### Model Architecture
- **Linear Regression** on standardized features (`StandardScaler` fit on train only).
- **Prediction post‑processing:** clip predictions to **[1, 5]** (valid AQI levels in this dataset).

## Training and Evaluation

### Training Procedure
- **Split:** per‑city time split (last 20% of rows per city → test).
- **Environment:** Python + scikit‑learn (notebook/Colab).
- **Hyperparameters (best model):** default scikit‑learn LinearRegression.

### Evaluation Metrics (Test Set)
- RMSE, MAE, MAPE, R²

**Results (best model):**
- RMSE: **0.968459**
- MAE: **0.692942**
- MAPE: **26.97%**
- R²: **0.336485**

**Comparison (all models):**
| Model | RMSE | MAE | MAPE | R² |
|---|---:|---:|---:|---:|
| Linear Regression | 0.968459 | 0.692942 | 26.967578 | 0.336485 |
| XGBoost | 1.013902 | 0.744450 | 29.516507 | 0.272758 |
| Random Forest | 1.023085 | 0.756943 | 30.077003 | 0.259524 |
| Hybrid LSTM‑GRU | 1.103536 | 0.790775 | 30.421396 | 0.138489 |
| LSTM | 1.249584 | 0.875271 | 35.091087 | -0.104635 |
| GRU | 1.296789 | 0.930587 | 38.212154 | -0.189668 |

### Evaluation Graphics
**Best-model forecast (first 300 points):**  
![](../assets/best_model_prediction_plot.png)

**Seasonality (monthly mean AQI):**  
![](../assets/monthly_mean_aqi.png)

**Explainability (SHAP):**  
![](../assets/shap_bar_best_model.png)

## Ethical Considerations
- **Fairness & Bias:** Data coverage may be uneven across cities, seasons, and events; model performance should be checked **per city** before any operational use.
- **Privacy:** Dataset is environmental; no personal data is used in the pipeline.
- **Security:** If deployed with real-time ingestion, the system could be vulnerable to data quality issues or malicious data injection; add validation, anomaly checks, and monitoring.

## Limitations and Recommendations
### Known Limitations
- AQI labels are discrete (1–5). Regression on discrete levels can produce low R² even when MAE/RMSE are reasonable.
- Missing dates cause imperfect “+3 day” alignment; shift approach is an approximation (small mismatch rate).
- The model is trained on historical patterns and may degrade under distribution shift (policy changes, wildfires, unusual meteorology).

### Recommendations for Use
- Round or calibrate predictions to the nearest AQI level if used as a classifier.
- Add a simple baseline (e.g., persistence `AQI(t)` or `AQI_lag1`) to contextualize performance.
- Report metrics per city and by season; consider additional features (meteorology, satellite, traffic proxies).

## Additional Information
### References
```text
Model cards overview: https://modelcards.withgoogle.com/about
Mitchell et al., “Model Cards for Model Reporting” (2019): https://arxiv.org/pdf/1810.03993.pdf
Kaggle example: https://www.kaggle.com/code/var0101/model-cards
```

### License
*(fill in — e.g., MIT for code; check dataset license separately)*

### Contact
*(fill in email / GitHub)*
