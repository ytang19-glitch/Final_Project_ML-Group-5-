# Architecture / Deployment Vision (High-Level)

This lab focuses on building and evaluating forecasting models. Below is a **deployment-oriented view** of how this pipeline could be used in practice (no actual integrations required).

## System overview

```mermaid
flowchart LR
  A[Data sources] --> B[Ingestion]
  B --> C[Data validation & cleaning]
  C --> D[Feature engineering<br/>time sin/cos + lags + rolling]
  D --> E[Model inference<br/>AQI(t+3)]
  E --> F[Outputs]
  F --> G[End users]

  A:::box
  B:::box
  C:::box
  D:::box
  E:::box
  F:::box
  G:::box

  classDef box fill:#f7f7f7,stroke:#999,stroke-width:1px;
```

### What “Data sources” could be
- historical CSV (current project setup)
- scheduled pull from public AQI/pollution APIs
- IoT sensors / station feeds
- meteorology sources (optional future feature enrichment)

## Serving options (examples)

### Option 1 — Batch daily/weekly forecast (simplest)
1. Scheduler (cron / GitHub Actions / Cloud Scheduler) triggers a job.
2. Job ingests latest data → builds features → runs the model.
3. Results saved to CSV/DB and emailed or pushed to a dashboard.

### Option 2 — Real-time inference API
- A small service (FastAPI) exposes `POST /predict` that:
  - validates incoming data
  - runs feature generation with required history
  - returns AQI level forecast + uncertainty/intervals (future work)

## Monitoring & quality checks (recommended)
- missing-rate and range checks on key pollutants
- drift detection (city-by-city)
- alert if prediction distribution collapses (e.g., always predicts “3”)

## Next steps (engineering + ML)
- Add a **persistence baseline** and per-city evaluation dashboard
- Swap regression for **ordinal classification** (since labels are 1–5)
- Add **uncertainty estimates** (quantile regression / conformal)
- Include external drivers (meteorology, holidays, wildfire indicators)
- Package pipeline into `src/` and `scripts/` for reproducible runs
